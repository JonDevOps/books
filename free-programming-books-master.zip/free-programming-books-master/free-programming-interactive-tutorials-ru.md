### Index

* [Git](#git)
* [Веб-разработка](#Веб-разработка)


### Git

* [Интерактивное обучение работе с git](https://githowto.com/ru)


### Веб-разработка

* [Open source воркшопы](https://nodeschool.io/ru)
* [Учитесь веб-разработке бесплатно!](http://codenamecrud.ru)
