### Index

* [Ajax](#ajax)
* [HTML](#html)
* [MySQL](#mysql)
* [PHP](#php)
* [Scratch](#scratch)


### Ajax

* [Ajax](http://etutoriale.ro/articles/1483/1/Tutorial-Ajax/)


### HTML

* [HTML](http://tutorialehtml.com/ro/introducere-in-html/)


### MySQL

* [MySQL](http://profs.info.uaic.ro/~busaco/teach/courses/net/docs/mysql-ro.pdf) (PDF)


### PHP

* [PHP](http://php.punctsivirgula.ro)


### Scratch

* [Informatica Creativa](http://scratched.gse.harvard.edu/resources/informatica-creativa-0)
