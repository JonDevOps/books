### Index

* [C](#c)
* [C++](#c-1)
* [PHP](#php)


### C

* [C-programmering](https://sv.wikibooks.org/wiki/C-programmering) - Wikibooks


### C++

* [Programmera spel i C++ för nybörjare](https://sv.wikibooks.org/wiki/Programmera_spel_i_C%2B%2B_f%C3%B6r_nyb%C3%B6rjare) - Wikibooks


### PHP

* [Programmera i PHP](https://sv.wikibooks.org/wiki/Programmera_i_PHP) - Wikibooks
