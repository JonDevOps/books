
module.exports = {
    add: require('./add'),
    sub: require('./sub')
};