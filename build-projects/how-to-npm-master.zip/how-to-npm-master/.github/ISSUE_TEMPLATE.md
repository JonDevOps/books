<!--
Thank you for reporting an issue!

Before you submit, please check https://github.com/workshopper/how-to-npm/issues to
make sure it isn't already being discussed.
-->
