 __»__ Um diese Anweisungen erneut auszugeben: `{appname} print`
 __»__ Um dein Programm in der Testumgebung auszuführen: `{appname} run program.js`
 __»__ Um dein Programm zu verifizieren:  `{appname} verify program.js`
 __»__ Für Hilfe: `{appname} help`
