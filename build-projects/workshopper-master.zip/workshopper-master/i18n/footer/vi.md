 __»__ Xem lại hướng dẫn: `{appname} print`
 __»__ Chạy chương trình với môi trường giả lập: `{appname} run program.js`
 __»__ Xác nhận chương trình: `{appname} verify program.js`
 __»__ Xem trợ giúp: `{appname} help`
