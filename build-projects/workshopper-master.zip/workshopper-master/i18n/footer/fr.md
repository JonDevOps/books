 __»__ Pour ré-afficher ces instructions, faites : `{appname} print`
 __»__ Pour exécuter votre programme dans un environnement de test, faites : `{appname} run program.js`
 __»__ Pour vérifier que votre programme résoud l’exercice, faites : `{appname} verify program.js`
 __»__ Pour de l’aide sur les commandes, faites : `{appname} help`
