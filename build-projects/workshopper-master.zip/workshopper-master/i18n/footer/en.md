 __»__ To print these instructions again, run: `{appname} print`
 __»__ To execute your program in a test environment, run: `{appname} run program.js`
 __»__ To verify your program, run: `{appname} verify program.js`
 __»__ For help run: `{appname} help`
