 __»__ 要再次显示此说明文本，请执行： `{appname} print`
 __»__ 要测试执行你的程序，请执行： `{appname} run program.js`
 __»__ 要验证你的程序，请执行： `{appname} verify program.js`
 __»__ 需要帮助？执行： `{appname} help`
