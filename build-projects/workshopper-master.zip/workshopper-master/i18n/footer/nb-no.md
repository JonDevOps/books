 __»__ For å skrive ut oppgaveteksten igjen kjør: `{appname} print`
 __»__ For å kjøre programmet i et test miljø kjør: `{appname} run program.js`
 __»__ For å verifisere programmet kjør: `{appname} verify program.js`
 __»__ For hjelp kjør: `{appname} help`
