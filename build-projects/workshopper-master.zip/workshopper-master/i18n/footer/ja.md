 __»__ この説明をもう一度表示する: `{appname} print`
 __»__ 作成したアプリをテスト環境で実行する: `{appname} run program.js`
 __»__ 作成したアプリが正しいか検証する: `{appname} verify program.js`
 __»__ 出力結果が見づらい場合には ``--no-color`` をつけてみてください: `{appname} verify program.js --no-color`
 __»__ ヘルプを表示する: `{appname} help`
