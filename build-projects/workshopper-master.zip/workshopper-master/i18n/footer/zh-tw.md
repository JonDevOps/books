 __»__ 顯示前一次說明，請輸入： `{appname} print`
 __»__ 在測試環境執行你的程式，請輸入： `{appname} run program.js`
 __»__ 驗證你的程式，請輸入： `{appname} verify program.js`
 __»__ 請求幫助，請輸入： `{appname} help`
