 __»__ Para imprimir essas instruções novamente execute: `{appname} print`
 __»__ Para executar seu programa em um ambiente de testes execute: `{appname} run program.js`
 __»__ Para que seu programa seja avaliado execute: `{appname} verify program.js`
 __»__ Para ajuda, execute: `{appname} help`
