 __»__ Para ver estas instrucciones de nuevo, ejecute: `{appname} print`
 __»__ Para ejecutar su programa en un entorno de pruebas, ejecute: `{appname} run program.js`
 __»__ Para verificar su programa, ejecute: `{appname} verify program.js`
 __»__ Para más información, ejecute: `{appname} help`
