 __»__ 설명을 다시 출력하시려면, `{appname} print`를 실행하세요.
 __»__ 테스트 환경에서 프로그램을 실행하시려면, `{appname} run program.js`를 실행하세요.
 __»__ 프로그램을 검증하시려면, `{appname} verify program.js`를 실행하세요.
 __»__ 도움말을 보시려면 `{appname} help`를 실행하세요.
