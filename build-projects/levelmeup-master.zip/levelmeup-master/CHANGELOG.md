# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.1"></a>
## [1.0.1](https://github.com/workshopper/levelmeup/compare/v1.0.0...v1.0.1) (2017-11-24)


### Bug Fixes

* **docs:** The code snippets in basic_get didn't fit the solution ([00dc8c9](https://github.com/workshopper/levelmeup/commit/00dc8c9))
* **exercise:** Multilevel explanation wasn't up-to-date with the current verification logic ([ccce5cf](https://github.com/workshopper/levelmeup/commit/ccce5cf))
