module.exports = function (x, y, cb) {
  cb(null, 'ALL YOUR ' + y + ' ARE BELONG TO ' + x)
}
