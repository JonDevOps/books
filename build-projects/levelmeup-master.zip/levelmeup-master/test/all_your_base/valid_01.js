module.exports = function (x, y, cb) {
  cb(null, 'ALL YOUR ' + x + ' ARE BELONG TO ' + y)
}
