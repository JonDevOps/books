module.exports = function (x, y, cb) {
  cb(null, 'all your ' + x + ' are belong to ' + y)
}
