module.exports = function (db, key, callback) {
  throw new Error('abcd')
}
