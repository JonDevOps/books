module.exports = function (db, key, callback) {}
