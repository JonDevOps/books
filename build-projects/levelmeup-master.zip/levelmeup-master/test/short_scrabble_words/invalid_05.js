module.exports = {
  init: function () {},
  query: 1
}
