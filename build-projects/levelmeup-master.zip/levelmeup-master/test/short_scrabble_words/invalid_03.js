module.exports = {
  init: 1
}
