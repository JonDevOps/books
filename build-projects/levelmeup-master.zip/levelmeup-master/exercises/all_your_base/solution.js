module.exports = function (X, Y, callback) {
  callback(null, 'ALL YOUR ' + X + ' ARE BELONG TO ' + Y)
}
