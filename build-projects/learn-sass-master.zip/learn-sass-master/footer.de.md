---
## HINWEISE

Um ein SASS-Stylesheet (SCSS-Stylesheet) zu erstellen, legt man eine neue Date mit der Endung `.scss` an und schreibt das SCSS. Ist man damit fertig, muss man


```sh
$ {appname} verify stylesheet.scss
```

ausführen, damit es läuft. Das Stylesheet wird dann getestet, ein Report wird erstellt und die Unterrichtseinheit wird als 'completed' gekennzeichnet, wenn alles erfolgreich war.
