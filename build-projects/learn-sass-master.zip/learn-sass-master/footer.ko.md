---
## 힌트

Sass(SCSS) 스타일 시트를 만들려면 `.scss` 확장자로 끝나는 파일을 만드세요. 그리고 과제를 모두 완료했다면 다음 명령어를 실행하세요.

```sh
$ {appname} verify stylesheet.scss
```

명령어가 실행되면 현재 만든 스타일 시트가 검토되며, 성공적이라면 'completed'가 표시됩니다.
