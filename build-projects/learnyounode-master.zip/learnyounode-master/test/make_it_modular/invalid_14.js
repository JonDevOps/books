// Triggers: fail.mod.unexpected_error
require('./module_invalid_13')(process.argv[2], process.argv[3], function () {})
