// Triggers: fail.mod.arguments
require('./module_invalid_02')
