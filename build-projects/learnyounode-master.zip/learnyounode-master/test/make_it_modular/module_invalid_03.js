module.exports = function (directory, filter, callback) {}
