# Javascript Challenges
This book will challenge you to learn and understand the most obscure and tricky parts of Javascript.

In order to perform the best that you can I recommend you not to cheat taking a look at solutions before you suggest one.

This book can be used as a learning resource for Javascript training if you want, but please send a tweet recommending us to other people.

I hope you enjoy this book because this is the purpose of this book.

Feedback is welcome.

Thanks a lot to [GITBOOK team](http://www.gitbook.io/) for it's amazing project to write your own books using Github repos.

