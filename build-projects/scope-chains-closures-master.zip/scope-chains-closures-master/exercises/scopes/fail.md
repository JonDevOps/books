# Almost there!

Check the errors above to see where you went wrong.

# Hints

 * Ensure you've created the variable using `var` to give it correct scope
 * Don't over think this problem - we're only getting warmed up.
 * Ensure you've named your variables correctly (`foo` & `bar`).

# More Help

 * If you're still having troubles, post a question in the nodeschool issues repository: http://bit.ly/scope-chains-question
