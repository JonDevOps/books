----

# Solution

For comparison, here is a possible solution, so you can compare notes:

```js
function foo() {
  var bar;
}
```

# Next lesson

Execute `$ADVENTURE_COMMAND` to move on to the next lesson: _Scope Chains_.
