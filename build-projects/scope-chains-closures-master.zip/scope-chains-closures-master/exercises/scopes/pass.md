# Success!

You correctly created the variable `bar`, lexically scoped inside the function
`foo()`, great work.
