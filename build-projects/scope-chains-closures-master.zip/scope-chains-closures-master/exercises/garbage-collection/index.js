var problem = require('../../problem');

module.exports = {
  title: 'Garbage Collection',
  problem: problem(__dirname, function (args, t) {
    t.end();
  })
}
