----

# Congratulations!

Now that you know all about Scope Chains, Closures, & Garbage Collection, why
not tweet about it: `http://bit.ly/sccjs-twitter-share`
