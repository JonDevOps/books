# Success!

You assigned a value to `quux`, even though `foo()` doesn't have access to the
`quux` inside `zip()`.
