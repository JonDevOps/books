# Almost there!

Check the errors above to see where you went wrong.

# Hints

 * Modifying your solution to lesson 2, _Scope Chains_, is a good start.
 * Don't use `var` or `let` when assigning the value to `quux` inside `foo()`

# More Help

 * If you're still having troubles, post a question in the nodeschool issues repository: http://bit.ly/scope-chains-question
