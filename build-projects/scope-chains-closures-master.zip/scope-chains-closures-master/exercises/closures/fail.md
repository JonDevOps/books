# Almost there!

Check the errors above to see where you went wrong.

# Hints

 * The task is to return the function `zip`, not the result of `zip()`.
 * The value you set to `bar` isn't important.

# More Help

 * If you're still having troubles, post a question in the nodeschool issues repository: http://bit.ly/scope-chains-question
