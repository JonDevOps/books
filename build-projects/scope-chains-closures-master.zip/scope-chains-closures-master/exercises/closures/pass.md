# Success!

Awesome stuff - you closed over the variable `bar` inside `zip`, then returned
`zip`.
