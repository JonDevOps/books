# Success!

You created a scope chain using lexical scoping and `var` statements!
