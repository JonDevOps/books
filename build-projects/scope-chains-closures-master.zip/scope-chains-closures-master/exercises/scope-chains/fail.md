# Almost there!

Check the errors above to see where you went wrong.

# Hints

 * Modifying your solution to lesson 1, _Scopes_, is a good start.
 * Ensure you've named your variables correctly (`foo`, `bar`, `zip`, & `quux`).

# More Help

 * If you're still having troubles, post a question in the nodeschool issues repository: http://bit.ly/scope-chains-question
