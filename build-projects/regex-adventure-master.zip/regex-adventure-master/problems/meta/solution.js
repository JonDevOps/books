// Here is the reference solution:

  module.exports = function (str) {
    return /\.$/.test(str)
  }
