// Here is the reference solution:

  module.exports = function (str) {
    return /^[aeiou0-9]/.test(str)
  }
