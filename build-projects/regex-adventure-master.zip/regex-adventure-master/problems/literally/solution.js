// Here is the reference solution:

  module.exports = function (str) {
    return /LITERALLY/.test(str)
  }
