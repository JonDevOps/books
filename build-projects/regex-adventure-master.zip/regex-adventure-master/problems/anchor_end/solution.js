// Here is the reference solution:

  module.exports = function (str) {
    return /BANANAS$/.test(str)
  }
