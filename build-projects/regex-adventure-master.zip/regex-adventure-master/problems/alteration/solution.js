// Here is the reference solution:

  module.exports = function (str) {
    return /^(cat|dog|robot)\d+$/.test(str)
  }
