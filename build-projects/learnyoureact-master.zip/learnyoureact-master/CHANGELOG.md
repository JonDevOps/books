# Change Log

All notable changes to this project will be documented from version 0.11.6 forward
in this file.
