learnyoureact
================
Let's learn React.js and server side rendering!

[![Join the chat at https://gitter.im/kohei-takata/learnyoureact](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/kohei-takata/learnyoureact?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

[![NPM](https://nodei.co/npm/learnyoureact.png?downloads=true&downloadRank=true&stars=true)](https://nodei.co/npm/learnyoureact/)

[![NPM](https://nodei.co/npm-dl/learnyoureact.png?months=3&height=3)](https://nodei.co/npm/learnyoureact/)


![learnyoureact.png](https://cloud.githubusercontent.com/assets/29263/8172581/e533bb88-1376-11e5-90d9-a2a2efed2b1d.png "learnyoureact.png")

# USAGE
`$ (sudo) npm i -g learnyoureact`

`$ learnyoureact`

# License
MIT
