---
# O-oh, quelque chose ne fonctionne pas.
# Mais ne paniquez pas !
---

## Vérifiez votre solution :

`Solution
===================`

%solution%

`Votre essai
===================`

%attempt%

`Différence
===================`

%diff%

## Autres pistes :
 * Avez-vous nommé correctement le fichier ? Vous pouvez vérifier en exécutant `ls %filename%`, si vous voyez `ls: cannot access %filename%: No such file or directory` c'est que vous devriez créer un nouveau fichier ou le renommer ou aller dans le dossier contenant le fichier.
 * Assurez-vous que vous n'avez pas oublié de parenthèse, sinon le compilateur ne sera pas capable d'analyser votre code.
 * Assurez-vous de ne pas avoir de faute de frappe dans la chaîne de caractère.
