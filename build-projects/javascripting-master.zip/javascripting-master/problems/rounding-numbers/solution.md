---

# THAT NUMBER IS ROUNDED

Yep, you just rounded the number `1.5` to `2`. Good job.

In the next challenge we will turn a number into a string.

Run `javascripting` in the console to choose the next challenge.

---
