---

# ESE NÚMERO ESTÁ REDONDEADO

¡Redondeaste el número `1.5` a `2`!

En el siguiente ejercicio convertiremos un número a una string.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
