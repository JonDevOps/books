---

# IL NUMERO È STATO ARROTONDATO

Perfetto, hai appena arrotondato il numero `1.5` a `2`. Ottimo lavoro.

Nella prossima sfida trasformeremo un numero in una stringa.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
