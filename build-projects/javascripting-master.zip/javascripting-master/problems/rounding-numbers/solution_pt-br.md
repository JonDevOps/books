---

# AGORA TÁ REDONDO!

Isso aê! Você arredondou o número `1.5` para `2`. Bom trabalho!

No próximo desafio iremos transformar o número numa string.

Execute `javascripting` no console para escolher o próximo desafio.

---
