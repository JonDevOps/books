---

# UAOO BANANE

Ce l'hai fatta! Hai creato una funzione che accetta un input, lo processa, e fornisce un output.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
