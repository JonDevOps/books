---

# ÅÅÅÅHÅÅI BANANAS

Du greide det! Du lagde en funksjon som tar data, prosesserer dataen og lager et resultat.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
