---

# ¡SE IMPRIMIÓ EL SEGUNDO ELEMENTO DEL ARRAY!

Buen trabajo, lograste acceder a ese elemento del array.

En el siguiente ejercicio trabajaremos un ejemplo de bucles usando arrays.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
