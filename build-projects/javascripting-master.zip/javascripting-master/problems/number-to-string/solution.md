---

# THAT NUMBER IS NOW A STRING!

Excellent. Good work converting that number into a string.

In the next challenge we will take a look at **if statements**.

Run `javascripting` in the console to choose the next challenge.

---
