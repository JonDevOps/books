---

# NUMMERET ER NÅ EN STRING!

Fantastisk. Godt jobba med å konvertere et nummer til en string.

I den neste oppgaven skal vi ta en titt på **if-setninger**.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
