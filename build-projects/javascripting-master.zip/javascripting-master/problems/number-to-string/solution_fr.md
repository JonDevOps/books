---

# CE NOMBRE EST MAINTENANT UNE CHAÎNE DE CARACTÈRES !

Excellent. Vous avez réussi à convertir un nombre en chaîne de caractères.

Dans le prochain défi, nous nous intéresserons aux **instructions if**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
