---

# SIM, PIZZA _É_ MARAVILHOSA.

Muito bem feito! Você acertou com o método `.replace()`!

Em seguida vamos explorar os **numbers**.

Execute `javascripting` no console para escolher o próximo desafio.

---
