---

# 是的, PIZZA _IS_ WONDERFUL。

幹得漂亮，你已經學會了如何使用 `.replace()` 方法！

接下來我們將探索 **numbers**，也就是**數字**。

運行 `javascripting` 命令並選擇下一個挑戰。

---
