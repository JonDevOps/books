---

# IL TOTALE È 45

Questa era una introduzione basilare ai cicli for, che sono utili in una varietà di situazioni, in particolare in combinazione con altri tipi di dati come stringhe e array.

Nella prossima sfida cominceremo a lavorare con gli **array**.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
