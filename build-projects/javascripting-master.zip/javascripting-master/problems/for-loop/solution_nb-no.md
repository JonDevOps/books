---

# TOTALEN ER 45

Det var en introduksjon til for løkker, som er veldig behjelpelig i mange situasjoner.
Spesielt i kombinasjon med andre data typer som strenger og arrayer.

I den neste oppgaven skal vi starte og jobbe med **arrayer**.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
