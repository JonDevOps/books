---

# LE TOTAL EST 45

Ceci était une introduction basique aux boucles. Elles sont utiles dans un grand nombre de situations, particulièrement dans des combinaisons avec d'autres types de données comme les chaînes de caractères et les tableaux.

Dans le prochain défi, nous allons travailler sur les **tableaux**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
