---

# CONDITIONAL MASTER

You got it! The string `orange` has more than five characters.

Get ready to take on **for loops** next!

Run `javascripting` in the console to choose the next challenge.

---
