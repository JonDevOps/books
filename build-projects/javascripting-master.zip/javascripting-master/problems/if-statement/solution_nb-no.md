---

# BESLUTNINGSMESTERN

Det fikk du til! Stringen `orange` har mer enn 5 bokstaver.

Gjør deg klar til prøve **for løkken** i neste oppgave!

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
