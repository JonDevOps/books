---

# SUCCESS! LOTS OF PETS!

Now all the items in that `pets` array are plural!

In the next challenge we will move from arrays to working with **objects**.

Run `javascripting` in the console to choose the next challenge.

---
