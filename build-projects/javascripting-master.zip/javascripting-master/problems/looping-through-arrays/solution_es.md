---

# EXCELENTE! MUCHAS MASCOTAS!

Ahora todos los ítems en el array `mascotas` son plurales!

En el siguiente ejercicio pasaremos de trabajar con arrays a trabajar con **objetos**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
