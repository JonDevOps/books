---

# SUCCESS! LOTS OF PETS!

Now all the items in that `pets` array are plural!

In the next challenge we will move from arrays to working with **objects**.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
