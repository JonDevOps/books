---

# VOCÊ DOMINOU OS ARGUMENTOS!

Muito bom! Você conseguiu completar o exercício.

Execute `javascripting` no console para escolher o próximo desafio.

---
