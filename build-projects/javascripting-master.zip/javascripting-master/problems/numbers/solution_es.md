---

# YEAH! NÚMEROS!

Genial, has definido correctamente una variable con el valor `123456789`.

En el siguiente ejercicio miraremos cómo manipular los números.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
