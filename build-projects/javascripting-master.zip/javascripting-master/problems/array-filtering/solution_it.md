---

# FILTRATO!

Ottimo lavoro nel filtrare l'array.

Nella prossima sfida lavoreremo su un esempio di accesso ai valori di un array.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
