Et array er en liste av verdier. Her er et eksempel:

```js
const dyr = ['katt', 'hund', 'rotte'];
```

### Oppgaven:

Lag en fil som heter `arrays.js`.

Definer en variabel med navnet `pizzaToppings` som refererer et array som inneholder tre strenger i følgende rekkefølge: `tomato sauce, cheese, pepperoni`

Bruk `console.log()` til å skrive ut `pizzaToppings` arrayet til skjermen.

Se om programmet ditt er riktig ved å kjøre kommandoen:

```bash
javascripting verify arrays.js
```
