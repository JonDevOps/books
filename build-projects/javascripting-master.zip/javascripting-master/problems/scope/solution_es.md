---

# EXCELENTE!

Lo hiciste! La segunda función tiene el ámbito que estabamos buscando.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.
---
