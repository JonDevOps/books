---

#EXCELENTE!

Você pegou o jeito! A segunda função tem o escopo que procurávamos.

Execute javascripting no console para escolher o próximo desafio.

---
