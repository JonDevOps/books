---

#ECCELLENTE!

Ce l'hai fatta! La seconda funzione possiede l'ambito che cercavamo.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
