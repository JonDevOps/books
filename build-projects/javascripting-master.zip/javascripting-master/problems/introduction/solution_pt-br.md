---

# VOCÊ CONSEGUIU!

Qualquer coisa entre os parênteses de `console.log()` é impresso no terminal.

Então isto: 

```js
console.log('hello');
```

imprime `hello` no terminal.

Atualmente estamos imprimindo uma **string** de caracteres para o terminal: `hello`.

No próximo desafio vamos nos focar em aprender sobre **variáveis**.

Execute `javascripting` no console para escolher o próximo desafio.
