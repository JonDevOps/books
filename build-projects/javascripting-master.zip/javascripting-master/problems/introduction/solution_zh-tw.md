---

# 完成！

任何於 `console.log()` 括號中的東西都將會被輸出到你的終端機（Terminal，於Windows下即命令提示字元）上。

所以：

```js
console.log('hello');
```

會印出 `hello` 到你的終端機。

此刻，我們輸出的是一個 **string**，中文名為**字串**。

接下來的挑戰裡我們將學習到 **variables**，也就是**變數**。

運行 `javascripting` 並選擇下一個挑戰。
