---

# 完成！

包裹于 `console.log()` 括号中的东西都将会被打印到终端。

所以：

```js
console.log('hello');
```

打印出 `hello` 到你的终端。

此刻，我们打印的是一个 **string**，中文名为**字符串**。

接下来的挑战里我们将学习到 **variables**，也就是**变量**。

运行 `javascripting` 并选择下一个挑战。
